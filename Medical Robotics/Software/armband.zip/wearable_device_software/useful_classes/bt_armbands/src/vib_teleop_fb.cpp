#include <iostream>
#include <string>
#include <sys/time.h>
#include <sirsiit_wearable/serial.h>
#include <sirsiit_wearable/HapticDevice.h>
#include <geometry_msgs/WrenchStamped.h>
#include <ros/ros.h>
#include <string>

class VibTeleop{
public:
    HapticDevice device;
    VibTeleop(ros::NodeHandle* n_in,int n,std::string topic, int multiplier, bool is_wrist){
        wrist=is_wrist;
        mult=multiplier;
        nh=n_in;
        int l_iHapticInitTrial=1;
        port=n;
        std::string g_sHapticPort;
        std::cout << "Starting" << std::endl;

        // device.init(0.5);
        g_sHapticPort = "/dev/rfcomm"+std::to_string(n);
        /*
        while (!device.startCommunication(g_sHapticPort.c_str()) && l_iHapticInitTrial < 5)
        {
            std::cout << "Try to connect : " << g_sHapticPort << " " << l_iHapticInitTrial << std::endl;
            l_iHapticInitTrial++;
            //       Sleep(0.3);
        }
*/

        fd=open(g_sHapticPort.c_str(), O_RDWR);
        sub_vib=nh->subscribe(topic,2,&VibTeleop::vib_callback,this);

        std::cout << "Go " << n << std::endl;

    }
    ~VibTeleop(){
        //   device.closeCommunication();
    }
    void update(){

        ROS_INFO_STREAM("A(" << port <<"): " << (int) cur_ft.wrench.torque.x*mult
                        << "," << (int) cur_ft.wrench.torque.y*mult);

        int lval,rval;
        if(wrist){
            lval=(int) fabs(cur_ft.wrench.force.x)*mult;
            rval=(int) fabs(cur_ft.wrench.force.y)*mult;
        }
        else{
            lval=(int) fabs(cur_ft.wrench.torque.x)*mult;
            rval=(int) fabs(cur_ft.wrench.torque.y)*mult;
        }

        unsigned char send[2];
        send[0]=lval & 0xFF;
        send[1]=rval & 0xFF;
        printf("%x - %x",send[0],send[1]);
        write(fd,send,2);
        /*

        sprintf(send,"echo -en \'\\x%02x\\x%02x' > /dev/rfcomm%d",lval,rval,port);
        printf("%s\n",send);
        std::system(send);
*/
        //device.sendSignal(lval,rval);
//        usleep(1.0 * 1000 * 1000);
    }

protected:
    ros::Subscriber sub_vib;
    ros::NodeHandle *nh;
    int port,mult;
    bool wrist;
    int fd;
    geometry_msgs::WrenchStamped cur_ft;
    void vib_callback(const geometry_msgs::WrenchStamped::ConstPtr& ee_force){
        if(wrist){
        	if((ee_force->wrench.force.x*ee_force->wrench.force.x+
           	ee_force->wrench.force.y*ee_force->wrench.force.y+
           	ee_force->wrench.force.z*ee_force->wrench.force.z)>10.0){
        		cur_ft=*ee_force;
    		}
        	else{
            	cur_ft.wrench.force.x=0;
            	cur_ft.wrench.force.y=0;        }
    		}
    	else{
    		if((ee_force->wrench.torque.x*ee_force->wrench.torque.x+
           	ee_force->wrench.torque.y*ee_force->wrench.torque.y+
           	ee_force->wrench.torque.z*ee_force->wrench.torque.z)>20.0){
        		cur_ft=*ee_force;
    		}
        	else{
            	cur_ft.wrench.torque.x=0;
            	cur_ft.wrench.torque.y=0;        }
    		}
    	}


};



int main(int argc, char *argv[])
{
    ros::init(argc, argv, "vib_teleop_fb");
    ros::NodeHandle *nh=new ros::NodeHandle();


    VibTeleop brac2(nh,0,"external_force_body",10,false);
    VibTeleop brac1(nh,1,"external_force",40,true);


    //    brac1.device.sendSignal(50,100);
    //vibs.push_back(VibTeleop(0,"external_force"));
    //ROS_INFO("AAA)");
    //vibs.push_back(VibTeleop(1,"external_force_body"));
    //vibs.at(0).device.sendSignal(50,100);

    ros::Rate rate(5);
    while(ros::ok()){
        ros::spinOnce();
        brac1.update();
        brac2.update();
        rate.sleep();
    }

    return 0;
}
