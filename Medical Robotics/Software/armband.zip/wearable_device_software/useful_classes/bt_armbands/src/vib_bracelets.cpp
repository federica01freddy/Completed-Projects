#include <iostream>
#include <string>
#include <sys/time.h>
#include <sirsiit_wearable/VibBrac.h>
#include <sirsiit_wearable/serial.h>
#include <sirsiit_wearable/HapticDevice.h>
#include <ros/ros.h>
#include <string>
#include <geometry_msgs/Twist.h>
#include <geometry_msgs/TwistStamped.h>
#include <ctime>

int Arr[2];
std::vector<HapticDevice> devices;
double previousTime=0.00;
double currentTime=0.00;
clock_t tStart;
bool first = true, second = false;


void hapticCallback(const geometry_msgs::TwistStamped::ConstPtr &msg)
{
  //void hapticCallback(const geometry_msgs::TwistStamped::ConstPtr &msg){
// std::cout << "Receiving data" << std::endl;
      
  int i=0;
    Arr[0]=msg->twist.linear.x;
    Arr[1]=msg->twist.linear.y;
    Arr[2]=msg->twist.linear.z;
    //Arr[0]=msg->linear.x;
    //Arr[1]=msg->linear.y;
    //Arr[2]=msg->linear.z;
  	currentTime= (double)(clock() - tStart)/CLOCKS_PER_SEC;
      

  
  if (currentTime-previousTime>=0.01)
  {
    for (int i = 0; i < devices.size(); i++)
    {
      if (Arr[i] > 0)
      {
        if (Arr[2] == 0)
        {
          devices.at(i).sendSignal(Arr[i],'a');
        }
        else
        {
          devices.at(i).sendSignal(Arr[i],'d');
        }
        
      }
      else
      {
        devices.at(i).sendSignal(0,'d');
      }  
    }
  previousTime=currentTime;
  }
}

class VibBrac
{
public:
  VibBrac(int n)
  {
    devices.resize(n);
    int l_iHapticInitTrial=1;

    std::string g_sHapticPort;
    std::cout << "Starting" << std::endl;

    
    for (int i=0;i<n;i++)
    {

      devices.at(i).init(0.5);
      g_sHapticPort = "/dev/rfcomm"+std::to_string(i);
      
      while (!devices.at(i).startCommunication(g_sHapticPort.c_str()) && l_iHapticInitTrial < 5)
      {
        std::cout << "Try to connect : " << g_sHapticPort << " " << l_iHapticInitTrial << std::endl;
        l_iHapticInitTrial++;
        Sleep(0.3);
      }
      
    }
    
    std::cout << "Done." << std::endl;
  }

  ~VibBrac()
  {
    for (int i=0;i<devices.size();i++)
    {
      devices.at(i).closeCommunication();
    }
  }
  
};




int main(int argc, char *argv[])
{
	
  ros::init(argc, argv, "haptic_data");
	ros::NodeHandle n;
	ros::Subscriber sub = n.subscribe("haptic_data0", 1000, &hapticCallback);
   VibBrac *vibs=new VibBrac(2);


    ros::spin();




  return 0;

}
