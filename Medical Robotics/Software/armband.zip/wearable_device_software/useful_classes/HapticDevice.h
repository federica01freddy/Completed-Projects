#ifndef HAPTICDEVICE_H_INCLUDED
#define HAPTICDEVICE_H_INCLUDED

#include <time.h>
#include "serial.h"
#include <boost/date_time/posix_time/posix_time.hpp>

#ifdef _WIN32
    #include <strsafe.h>
    #include <process.h> 
    #include <boost/thread.hpp>
    #include <boost/lexical_cast.hpp>
    #include <boost/bind.hpp>		
#else
    #include <pthread.h> 
#endif

class HapticDevice
{
public:
    #ifdef _WIN32
        Serial* identifier;
    #else
        int identifier;
    #endif
    double interval;
    bool is_connected, is_synchronized, sendData;
    
	void init(double value)
	{
		is_connected = false;
		is_synchronized = false;
		interval = value;
		sendData = false;
    
		#ifndef _WIN32
			identifier = -1;
			pthread_mutex_init(&posMutex, NULL);
		#endif
	}

	bool startLoop()
	{
		running = true;
    
		#ifdef _WIN32 
			boost::thread hapticThread(&HapticDevice::loop, this, this);
			return true;
		#else
			pthread_t hp;
			int rc;
        
			rc = pthread_create(&hp, NULL, HapticDevice::loop, this);
        
			if (rc)
				return false;
			else 
				return true;
		#endif
	}

	void stopLoop()
	{
		this->running = false;
	}
		
    void sendSignal(int frequency,char interval)
	{
		#ifdef _WIN32 
			char buffer[4];
			sprintf(buffer,"S%02x%cE",frequency, char);
			if(!this->identifier->WriteData(buffer,2))
			{
				printf("Error in sending data\n");
			}
		#else
			int i;
			int buffer[4] = {'S',frequency, interval,'E'};
			for(i = 0; i < 4; i++)
				serialport_writebyte(this->identifier, buffer[i]);
		#endif
	}

    void stopMotors()
	{
		#ifdef _WIN32 
			char buffer[2];
			sprintf(buffer,"%c%c",0, 0);
			if(!this->identifier->WriteData(buffer,2))
			{
				printf("Error in sending data\n");
			}
		#else
			int i;
			for(i = 0; i < 2; i++)
				serialport_writebyte(this->identifier, 0);
		#endif
	}
    
    
    // _________
    /*bool checkSynchronization()
    {
        #ifndef _WIN32 
            char b[1];
            for (int i = 0; i < 5; i++)
            {
                Sleep( 20 ); // wait 20 msec
                int n = read(this->identifier, b, 1);  // read a char at a time
                if( n==0 || n==-1 )
                {
                    continue;
                }
                else
                {
                    return true;
                }
            }
            return false;
        #endif
    }*/
    
	void checkSynchronization()
    {
		this->is_synchronized = false;
		
		char buf[36];
		
		for (int checkSynch = 0; checkSynch < 4; checkSynch++)
		{
			this->sendByte(0);
			Sleep(0.1 * 1000);
			int res = read(this->identifier, buf, 1);
			
			if ((int)buf[0] == 0)
			{
                std::cout << "Synchronization ok!"<< std::endl;
				this->is_synchronized = true;				
				return;				
			}			
		}		
	}
    
    void sendByte(int value)
	{
        #ifdef _WIN32 
            char buffer;
            sprintf(buffer,"%c",value);
            if(!this->identifier->WriteData(buffer,1))
            {
                printf("Error in sending data\n");
            }
        #else
            int i;
            int buffer = value;
            serialport_writebyte(this->identifier, buffer);
        #endif
	}
    //__________

	bool setIdentifier(const char* serialport)
	{
		
	}

	bool startCommunication(const char* serialport)
	{
		#ifdef _WIN32 
			Serial* serialTmp = new Serial(serialport);
			this->identifier = serialTmp;
			if(this->identifier->IsConnected())
            {
				this->is_connected = true;
                return true;
            }
            return false;
		#else
			this->identifier = serialport_init(serialport);
			if (this->identifier >= 0)
            {
				this->is_connected = true;
                return true;
            }
            return false;
		#endif
	}

    void closeCommunication()
	{
        this->stopMotors();
		Sleep(0.1 * 1000);
		
		if (this->running)
		{
			this->stopLoop();
		}
		this->is_connected = false;
    
		#ifdef _WIN32 
			this->identifier->~Serial();
		#else
			serialport_close(this->identifier);
		#endif
	}


private:
    bool running;
    
	#ifdef _WIN32 
		void loop(void *param)
    #else
        pthread_mutex_t posMutex;
        static void *loop(void *param)
	#endif
	{
        
        // unix
        HapticDevice *that = (HapticDevice *)param;
        
        
		int motorCounter = 0;
        //clock_t now, prev;
        boost::posix_time::ptime now, prev;
        boost::posix_time::time_duration diff;
        
		
        //prev = clock();
        prev = boost::posix_time::microsec_clock::local_time();
        

		while(that->running)
		{
			// milliseconds
			//now = clock();
            now = boost::posix_time::microsec_clock::local_time();
			//double felapsedTime = ((float)now - (float)prev)/CLOCKS_PER_SEC; // convert to float
            diff = now - prev;
            double felapsedTime = diff.total_milliseconds()/1000.0;
            
			// timer
			if(that->sendData && felapsedTime > that->interval) // start computing signal
			{
				if((motorCounter % 2) == 0)
				{
					that->sendSignal(255, 0);
				}
				else if((motorCounter % 2) == 1)
				{
					that->sendSignal(0, 255);
				}
				
				prev = now;

				motorCounter = (++motorCounter) % 2; // increment motors counter
			}
		}
	}
};

#endif
