# Steps to connect a device on Ubuntu (tested on Ubuntu 14.04)

## 1. Scan for devices for finding the MAC address
The MAC address of the device to pair can be found by using the `scan` function of `hcitool`
```shell
hcitool scan
```
Example output:
```shell
$ hcitool scan
Scanning ...
	00:06:66:D1:F9:54	RNBT-F954
```


## 2. Pair the device
A device can be paired either using the Bluetooth section of `gnome-control-center` (video) or with the `connect` function of `bt-device`
```shell
bt-device --connect 00:06:66:D1:F9:54
```
This step can be avoided if the device is already paired; to know the list of the already paired devices, the `list` function of `bt-device` can be useful
```shell
bt-device --list
```
Example output:
```shell
$ bt-device --list
Added devices:
RNBT-F954 (00:06:66:D1:F9:54)
RNBT-9E34 (00:06:66:A0:9E:34)
RNBT-FD42 (00:06:66:D1:FD:42)
RNBT-97F2 (00:06:66:84:97:F2)
RNBT-3C61 (00:06:66:6C:3C:61)
```

## 3. Connect the device 
To connect the paired device to the Bluetooth antenna, `rfcomm` is handy; `rfcomm` creates a file in `/dev/` acting as a serial port where bytes can be written and read. The number of `rfcomm` range from 0 to 255 (TODO: check this).
To connect a device (e.g., MAC address `00:06:66:D1:F9:54`) to the first `rfcomm` port (e.g., `/dev/rfcomm0`), the `connect` function is used
```shell
sudo rfcomm connect 0 00:06:66:D1:F9:54
```
Example output:
```shell
$ sudo rfcomm connect 0 00:06:66:D1:F9:54
Connected /dev/rfcomm0 to 00:06:66:D1:F9:54 on channel 1
Press CTRL-C for hangup

```
More information on how to use `rfcomm` can be found in `MISSING LINK`.


# Various useful commands
#### Restart Bluetooth manager if needed (on Ubuntu 14.04, may be different for other realese)
```shell
sudo /etc/init.d/bluetooth restart
```

#### To know which process is using rfcommX (if the port is busy)
```shell
sudo lsof | grep /dev/rfcommX
```

#### Communicate with the device in command line
A possible way to communicate with the device is to write directly from command line on the *connected* `rfcomm` port. This method sends bytes in hexadecimal format. Supposing the device is connected on `/dev/rfcomm0` and that it is controlled with the [`SafE`](safe-arduino-code) protocol, the sending `SaaE` would look like
```shell
echo -en '\x53\x61\x61\x45' > /dev/rfcomm0
```

#### Remove the device for pairing it again
```shell
bt-device --remove MAC::ADDRESS
```