#ifndef SERIALCLASS_H_INCLUDED
#define SERIALCLASS_H_INCLUDED

#ifndef _WIN32
#define Sleep(x) usleep((x)*1000*1000)
#endif

        #include <cstring>
        #include <stdio.h>
        #include <stdint.h>
        #include <termios.h>
        #include <fcntl.h>
	#include <stdlib.h>
	#include <unistd.h>
        
	typedef unsigned char uint8_t;

        int serialport_init(const char* serialport)
		{
			struct termios toptions;
			int fd;
        
			fd = open(serialport, O_RDWR | O_NOCTTY | O_NDELAY);
			if (fd == -1)  {
				printf("init_serialport: Unable to open port ");
				return -1;
			}
        
			if (tcgetattr(fd, &toptions) < 0) {
				printf("init_serialport: Couldn't get term attributes");
				return -1;
			}
			int baud = 9600;
			speed_t brate = baud; // let you override switch below if needed
			switch(baud) {
				case 4800:   brate=B4800;   break;
				case 9600:   brate=B9600;   break;
		#ifdef B14400
				case 14400:  brate=B14400;  break;
		#endif
				case 19200:  brate=B19200;  break;
		#ifdef B28800
				case 28800:  brate=B28800;  break;
		#endif
				case 38400:  brate=B38400;  break;
				case 57600:  brate=B57600;  break;
				case 115200: brate=B115200; break;
			}
			cfsetispeed(&toptions, brate);
			cfsetospeed(&toptions, brate);

        
			// rs232
			toptions.c_cflag = brate | CS8 | CLOCAL | CREAD;
			toptions.c_iflag = IGNPAR;
			toptions.c_oflag = 0;
			toptions.c_lflag = 0;
			toptions.c_cc[VMIN] = 0;      /* block untill n bytes are received */
			toptions.c_cc[VTIME] = 0;     /* block untill a timer expires (n * 100 mSec.) */
        
        
			if( tcsetattr(fd, TCSANOW, &toptions) < 0) 
			{
				printf("init_serialport: Couldn't set term attributes");
				return -1;
			}
        
			return fd;
		}
        int serialport_writebyte( int fd, uint8_t b)
		{
			int n = write(fd,&b,1);
			if( n!=1)
				return -1;
			return 0;
		}
		int serialport_write(int fd, const char* str)
		{
			int len = strlen(str);
			int n = write(fd, str, len);
			if( n!=len ) 
			return -1;
			return 0;
		}
        int serialport_read_until(int fd, char* buf, char until)
		{
			char b[1];
			int i=0;
			do { 
				int n = read(fd, b, 1);  // read a char at a time
				if( n==0 || n==-1 ) 
				{
					Sleep( 10 ); // wait 10 msec try again
					continue;
				}
				buf[i] = b[0]; i++;
			} while( b[0] != until );
        
			buf[i] = 0;  // null terminate the string
			return 0;
		}
	    int serialport_close(int fd)
		{
			// 0 - ok
			// -1 - error
			return close(fd);
		}
#endif // SERIALCLASS_H_INCLUDED
