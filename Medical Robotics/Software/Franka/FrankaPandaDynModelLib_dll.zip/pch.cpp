// pch.cpp: file di origine corrispondente all'intestazione precompilata

#include "pch.h"

// Quando si usano intestazioni precompilate, questo file è necessario per la riuscita della compilazione.
